import flet as ft
import math
import datetime
import pandas as pd
import json
import os

wolf_name = "Волчара"
DIARY_FILE = "training_diary.json"

def load_diary():
    if os.path.exists(DIARY_FILE):
        try:
            with open(DIARY_FILE, "r", encoding="utf-8") as f:
                data = json.load(f)
                if isinstance(data, list):
                    return {"plan_pm": "", "plan_start_date": "", "workouts": data}
                return data
        except Exception:
            pass
    return {"plan_pm": "", "plan_start_date": "", "workouts": []}

def save_diary(data):
    with open(DIARY_FILE, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=4)

async def main(page: ft.Page):
    page.title = "Тренировочный комплекс"
    
    saved_first_name = ""
    saved_last_name = ""
    diary_data = load_diary()

    page.locale_configuration = ft.LocaleConfiguration(
        supported_locales=[ft.Locale("ru", "RU")],
        current_locale=ft.Locale("ru", "RU")
    )

    # ==========================================
    # ЭКРАН ПРИВЕТСТВИЯ
    # ==========================================
    def go_to_app(e):
        page.controls.clear()
        page.add(tabs)
        page.update()

    splash_view = ft.Container(
        expand=True,
        content=ft.Column(
            [
                ft.Image(
                    src="WolfHello.jpg", #не забудь про картинку
                    width=250, height=250, fit=ft.BoxFit.COVER, border_radius=20,
                ),
                ft.Text("Тренировочный комплекс", size=24, weight=ft.FontWeight.BOLD),
                ft.Text("Твой путь к силе", size=16, color=ft.Colors.GREY_700),
                ft.Container(height=30),
                ft.Button(
                    content=ft.Row(
                        controls=[ft.Text("Перейти к составлению плана", color=ft.Colors.GREEN_900)],
                        alignment=ft.MainAxisAlignment.CENTER,
                    ),
                    on_click=go_to_app,
                    width=250, height=50, 
                    bgcolor=ft.Colors.GREEN_100
                )
            ],
            alignment=ft.MainAxisAlignment.CENTER,
            horizontal_alignment=ft.CrossAxisAlignment.CENTER,
        )
    )

    # ==========================================
    # ВКЛАДКА 1: Приветствие
    # ==========================================
    first_name = ft.TextField(label="Имя", width=300)
    last_name = ft.TextField(label="Фамилия", width=300)
    greetings = ft.Column(horizontal_alignment=ft.CrossAxisAlignment.CENTER)

    def btn_click(e):
        nonlocal saved_first_name, saved_last_name
        saved_first_name = first_name.value
        saved_last_name = last_name.value

        greetings.controls.clear() 
        greetings.controls.append(
            ft.Text(
                f"Привет, {last_name.value} {wolf_name} {first_name.value}!",
                color=ft.Colors.GREEN,
            )
        )
        last_name.value = ""
        first_name.value = ""
        page.update()

    tab1_content = ft.Container(
        expand=True,
        content=ft.Row(
            alignment=ft.MainAxisAlignment.CENTER,
            vertical_alignment=ft.CrossAxisAlignment.CENTER,
            controls=[
                ft.Column(
                    [
                        last_name,
                        first_name,
                        ft.Button(content="Показать приветствие", on_click=btn_click),
                        greetings,
                    ],
                    horizontal_alignment=ft.CrossAxisAlignment.CENTER,
                    tight=True,
                )
            ],
        ),
    )

    # ==========================================
    # ВКЛАДКА 2: Тренировочный план
    # ==========================================
    target_weight_field = ft.TextField(label="Введи ПМ, кг", value="135", width=150)
    start_date_text = ft.TextField(label="Дата начала", value=datetime.date.today().strftime("%Y-%m-%d"), read_only=True, width=150)

    date_picker = ft.DatePicker(
        first_date=datetime.datetime(2020, 1, 1),
        last_date=datetime.datetime(2030, 12, 31),
        on_change=lambda e: update_date_text(e.control.value)
    )
    page.overlay.append(date_picker)

    def update_date_text(selected_date):
        if selected_date:
            start_date_text.value = selected_date.strftime("%Y-%m-%d")
            page.update()

    def open_date_picker(e):
        page.show_dialog(date_picker)

    file_picker = ft.FilePicker()
    plan_area = ft.Column(scroll=ft.ScrollMode.AUTO, horizontal_alignment=ft.CrossAxisAlignment.CENTER)
    plan_error_text = ft.Text("", color=ft.Colors.RED)

    percentages = [95, 93, 91, 89, 87, 85, 83, 81, 79, 77, 75]

    def on_day_change(e):
        selected = [cb for cb in days_checkboxes if cb.value]
        if len(selected) > 3:
            e.control.value = False
            plan_error_text.value = "Можно выбрать не более 3 дней в неделю!"
        else:
            plan_error_text.value = ""
        page.update()

    days_checkboxes = [
        ft.Checkbox(label="ПН", value=True, on_change=on_day_change),
        ft.Checkbox(label="ВТ", value=False, on_change=on_day_change),
        ft.Checkbox(label="СР", value=True, on_change=on_day_change),
        ft.Checkbox(label="ЧТ", value=False, on_change=on_day_change),
        ft.Checkbox(label="ПТ", value=True, on_change=on_day_change),
        ft.Checkbox(label="СБ", value=False, on_change=on_day_change),
        ft.Checkbox(label="ВС", value=False, on_change=on_day_change),
    ]

    days_selection_container = ft.Container(
        content=ft.Column([
            ft.Text("Выбери тренировочные дни (макс. 3)", weight=ft.FontWeight.BOLD, size=14),
            ft.Row(days_checkboxes, alignment=ft.MainAxisAlignment.CENTER, wrap=False, scroll=ft.ScrollMode.AUTO)
        ], horizontal_alignment=ft.CrossAxisAlignment.CENTER, spacing=10),
        padding=15, border=ft.Border.all(1, ft.Colors.GREY_300), border_radius=10, bgcolor=ft.Colors.GREY_50,
    )

    program_data = {
        1: [None, None, None, None, None, None, None, None, None, None, "5*6"],
        2: [None, None, None, None, "5*2", None, None, None, None, None, None],
        3: [None, None, None, None, None, None, None, None, None, "6", "4*6"],
        4: [None, None, None, "2", "4*2", None, None, None, None, None, None],
        5: [None, None, None, None, None, None, None, None, "6", "6", "3*6"],
        6: [None, None, "2", "2", "3*2", None, None, None, None, None, None],
        7: [None, None, None, None, None, None, None, "6", "6", "6", "2*6"],
        8: [None, "2", "2", "2", "2*2", None, None, None, None, None, None],
        9: [None, None, None, None, None, None, "6", "6", "6", "6", "6"],
        10: ["2", "2", "2", "2", "2", None, None, None, None, None, None],
        11: [None, None, None, None, None, None, "6", "6", "6", "2*6", None],
        12: ["2", "2", "2", "2*2", None, None, None, None, None, None, None],
        13: [None, None, None, None, None, None, "6", "6", "3*6", None, None],
        14: ["2", "2", "3*2", None, None, None, None, None, None, None, None],
        15: [None, None, None, None, None, None, "6", "4*6", None, None, None],
        16: ["2", "4*2", None, None, None, None, None, None, None, None, None],
        17: [None, None, None, None, None, None, "5*6", None, None, None, None],
        18: ["5*2", None, None, None, None, None, None, None, None, None, None],
        19: [None, None, None, None, None, None, None, None, None, "3*4", None],
    }

    def get_calculated_data():
        max_w = float(target_weight_field.value.replace(",", ".").strip())
        calculated_weights = [math.floor(max_w * p / 100 / 2.5) * 2.5 for p in percentages]
        start_date = datetime.datetime.strptime(start_date_text.value, "%Y-%m-%d").date()
        selected_days = [i for i, cb in enumerate(days_checkboxes) if cb.value]
        if not selected_days:
            raise ValueError("No days selected")
        return calculated_weights, start_date, selected_days

    def build_plan(e):
        plan_error_text.value = ""
        try:
            calculated_weights, start_date, selected_days = get_calculated_data()
        except (TypeError, ValueError):
            plan_error_text.value = "Проверьте правильность ввода"
            page.update()
            return

        columns = [
            ft.DataColumn(label=ft.Container(content=ft.Text("Дата", weight=ft.FontWeight.BOLD), bgcolor=ft.Colors.GREEN_100, padding=5, border_radius=5))
        ]
        for pct in percentages:
            columns.append(ft.DataColumn(label=ft.Text(f"{pct}%", size=13, weight=ft.FontWeight.BOLD)))

        rows = []
        start_monday = start_date - datetime.timedelta(days=start_date.weekday())
        num_days = len(selected_days)
        sorted_training_keys = sorted(program_data.keys())
        
        for idx, training_num in enumerate(sorted_training_keys):
            cells = program_data[training_num]
            week_num = idx // num_days
            day_idx = idx % num_days
            day_offset = selected_days[day_idx]
            training_date = start_monday + datetime.timedelta(weeks=week_num, days=day_offset)
            date_str = training_date.strftime("%d.%m.%Y")
            day_label = f"Нед. {week_num + 1}" if num_days == 1 else f"Нед. {week_num + 1}, Трен. {idx + 1}"
            
            row_cells = [
                ft.DataCell(
                    ft.Container(
                        content=ft.Column([
                            ft.Text(date_str, weight=ft.FontWeight.BOLD, size=13),
                            ft.Text(day_label, size=10, color=ft.Colors.GREY_700)
                        ], spacing=0, alignment=ft.MainAxisAlignment.CENTER),
                        bgcolor=ft.Colors.GREEN_50,
                        padding=ft.Padding.only(left=5, right=5, top=5, bottom=5),
                    )
                )
            ]
            for cell, weight in zip(cells, calculated_weights):
                if cell:
                    cell_content = ft.Column([
                        ft.Text(f"{weight:.1f} кг", color=ft.Colors.RED, weight=ft.FontWeight.BOLD, size=11),
                        ft.Text(cell, color=ft.Colors.GREEN_800, weight=ft.FontWeight.BOLD, size=13)
                    ], spacing=0, alignment=ft.MainAxisAlignment.CENTER, horizontal_alignment=ft.CrossAxisAlignment.CENTER)
                    row_cells.append(ft.DataCell(cell_content))
                else:
                    row_cells.append(ft.DataCell(ft.Text("")))
            rows.append(ft.DataRow(cells=row_cells))

        table = ft.DataTable(
            columns=columns, rows=rows, border=ft.Border.all(1, ft.Colors.GREY_400),
            vertical_lines=ft.BorderSide(1, ft.Colors.GREY_300), horizontal_lines=ft.BorderSide(1, ft.Colors.GREY_300),
            heading_row_color=ft.Colors.GREY_100,
        )
        plan_area.controls = [ft.Row([table], scroll=ft.ScrollMode.ALWAYS, alignment=ft.MainAxisAlignment.CENTER)]
        page.update()

    # ==========================================
    # ВКЛАДКА 3: Тренировочный дневник
    # ==========================================
    diary_container = ft.Column(scroll=ft.ScrollMode.AUTO, horizontal_alignment=ft.CrossAxisAlignment.START, expand=True)

    def on_diary_check(e, index):
        diary_data["workouts"][index]["completed"] = e.control.value
        save_diary(diary_data)
        refresh_diary_ui() # ✅ Обновляем интерфейс, чтобы перекрасить строки

    def delete_diary(e):
        def confirm_delete(e):
            page.pop_dialog()
            nonlocal diary_data
            diary_data = {"plan_pm": "", "plan_start_date": "", "workouts": []}
            save_diary(diary_data)
            refresh_diary_ui()
            page.snack_bar = ft.SnackBar(ft.Text("Записи успешно удалены!"), bgcolor=ft.Colors.GREEN)
            page.snack_bar.open = True
            page.update()

        def cancel_delete(e):
            page.pop_dialog()

        confirm_dialog = ft.AlertDialog(
            title=ft.Text("Подтверждение"),
            content=ft.Text("Уверены, что хотите удалить ВСЕ записи из дневника?\nЭто действие нельзя отменить."),
            actions=[
                ft.TextButton("Да, удалить", on_click=confirm_delete),
                ft.TextButton("Отмена", on_click=cancel_delete)
            ]
        )
        page.show_dialog(confirm_dialog)

    def refresh_diary_ui():
        diary_container.controls.clear()
        workouts = diary_data.get("workouts", [])
        
        if not workouts:
            diary_container.controls.append(ft.Text("Дневник пуст. Сначала постройте план и нажмите 'Записать в Дневник'.", color=ft.Colors.GREY))
        else:
            first_workout_date = workouts[0]["date"]
            
            plan_info_row = ft.Row(
                controls=[
                    ft.Text(
                        f"Сохраненный план: ПМ = {diary_data.get('plan_pm', '?')} кг, Первая тренировка = {first_workout_date}", 
                        size=12, color=ft.Colors.BLUE_700, weight=ft.FontWeight.BOLD,
                        expand=True
                    ),
                    ft.Button(
                        content="Удалить записи", 
                        icon=ft.Icons.DELETE, 
                        bgcolor=ft.Colors.RED_100, 
                        color=ft.Colors.RED_900,
                        on_click=delete_diary
                    )
                ],
                alignment=ft.MainAxisAlignment.SPACE_BETWEEN,
                vertical_alignment=ft.CrossAxisAlignment.CENTER
            )
            
            diary_container.controls.append(plan_info_row)
            diary_container.controls.append(ft.Divider())

            # ✅ Находим индекс первой НЕвыполненной тренировки
            next_uncompleted_idx = -1
            for i, item in enumerate(workouts):
                if not item['completed']:
                    next_uncompleted_idx = i
                    break
            
            for i, item in enumerate(workouts):
                sets_text = " | ".join([f"{p}%: {w}" for p, w in zip(percentages, item['weights']) if w])
                
                cb = ft.Checkbox(
                    label=f"{item['date']} [{item['label']}] — {sets_text}",
                    value=item['completed'],
                    on_change=lambda e, idx=i: on_diary_check(e, idx)
                )
                
                # ✅ Определяем цвет фона
                bg_color = None
                if item['completed']:
                    bg_color = ft.Colors.GREEN_100 # Выполненные - зеленые
                elif i == next_uncompleted_idx:
                    bg_color = ft.Colors.RED_100   # Следующая - красная
                
                # ✅ Оборачиваем чекбокс в контейнер с фоном
                row_container = ft.Container(
                    content=cb,
                    bgcolor=bg_color,
                    padding=ft.Padding.all(5),
                    border_radius=5,
                )
                
                diary_container.controls.append(row_container)
                
        page.update()

    refresh_diary_ui()

    def write_to_diary(e):
        plan_error_text.value = ""
        try:
            calculated_weights, start_date, selected_days = get_calculated_data()
        except (TypeError, ValueError):
            plan_error_text.value = "Сначала постройте корректный план!"
            page.update()
            return

        current_pm = target_weight_field.value.strip()
        current_date = start_date_text.value.strip()

        if diary_data.get("plan_pm") == current_pm and diary_data.get("plan_start_date") == current_date:
            dialog = ft.AlertDialog(
                title=ft.Text("Внимание"),
                content=ft.Text("Такой план уже есть в Дневнике (совпадают ПМ и дата начала)."),
                actions=[ft.TextButton("ОК", on_click=lambda e: page.pop_dialog())]
            )
            page.show_dialog(dialog)
            return

        def confirm_write(e):
            page.pop_dialog()
            
            nonlocal diary_data
            workouts_list = []
            
            start_monday = start_date - datetime.timedelta(days=start_date.weekday())
            num_days = len(selected_days)
            sorted_training_keys = sorted(program_data.keys())

            for idx, training_num in enumerate(sorted_training_keys):
                cells = program_data[training_num]
                week_num = idx // num_days
                day_offset = selected_days[idx % num_days]
                training_date = start_monday + datetime.timedelta(weeks=week_num, days=day_offset)
                date_str = training_date.strftime("%d.%m.%Y")
                day_label = f"Нед. {week_num + 1}" if num_days == 1 else f"Нед. {week_num + 1} (Трен. {idx + 1})"
                
                weights_data = []
                for cell, weight in zip(cells, calculated_weights):
                    if cell:
                        weights_data.append(f"{weight:.1f} кг / {cell}")
                    else:
                        weights_data.append("")

                workouts_list.append({
                    "date": date_str,
                    "label": day_label,
                    "weights": weights_data,
                    "completed": False
                })

            diary_data = {
                "plan_pm": current_pm,
                "plan_start_date": current_date,
                "workouts": workouts_list
            }

            save_diary(diary_data)
            refresh_diary_ui()
            tabs.selected_index = 2
            page.update()

        def cancel_write(e):
            page.pop_dialog()

        confirm_dialog = ft.AlertDialog(
            title=ft.Text("Подтверждение"),
            content=ft.Text("Уверены, что хотите записать в дневник?\nПредыдущая запись будет удалена!"),
            actions=[
                ft.TextButton("Да", on_click=confirm_write),
                ft.TextButton("Отмена", on_click=cancel_write)
            ]
        )
        page.show_dialog(confirm_dialog)

    async def export_to_excel(e):
        plan_error_text.value = ""
        try:
            calculated_weights, start_date, selected_days = get_calculated_data()
        except (TypeError, ValueError):
            plan_error_text.value = "Сначала введите корректные данные"
            page.update()
            return

        current_first = first_name.value.strip() if first_name.value else saved_first_name.strip()
        current_last = last_name.value.strip() if last_name.value else saved_last_name.strip()
        name_parts = [p for p in [current_last, current_first] if p]
        name_prefix = "_".join(name_parts) + "_" if name_parts else ""
        default_filename = f"{name_prefix}Тренировочный_план.xlsx"

        save_path = await file_picker.save_file(
            dialog_title="Сохранить тренировочный план",
            file_name=default_filename,
            allowed_extensions=["xlsx"]
        )
        if not save_path: return

        columns_excel = ["Неделя / Тренировка", "Дата"] + [f"{p}%" for p in percentages]
        data_for_excel = []
        start_monday = start_date - datetime.timedelta(days=start_date.weekday())
        num_days = len(selected_days)
        sorted_training_keys = sorted(program_data.keys())

        for idx, training_num in enumerate(sorted_training_keys):
            cells = program_data[training_num]
            week_num = idx // num_days
            day_offset = selected_days[idx % num_days]
            training_date = start_monday + datetime.timedelta(weeks=week_num, days=day_offset)
            date_str = training_date.strftime("%d.%m.%Y")
            day_label = f"Неделя {week_num + 1}" if num_days == 1 else f"Неделя {week_num + 1} (Трен. {idx + 1})"
            row_data = [day_label, date_str]
            for cell, weight in zip(cells, calculated_weights):
                row_data.append(f"{weight:.1f} кг / {cell}" if cell else "")
            data_for_excel.append(row_data)

        df = pd.DataFrame(data_for_excel, columns=columns_excel)
        with pd.ExcelWriter(save_path, engine='openpyxl') as writer:
            df.to_excel(writer, index=False, sheet_name='План')
            worksheet = writer.sheets['План']
            worksheet.column_dimensions['A'].width = 22
            worksheet.column_dimensions['B'].width = 12

        page.snack_bar = ft.SnackBar(ft.Text("Файл успешно сохранен!"), bgcolor=ft.Colors.GREEN)
        page.snack_bar.open = True
        page.update()

    # ==========================================
    # СБОРКА ИНТЕРФЕЙСА
    # ==========================================
    tab2_content = ft.Container(
        expand=True,
        content=ft.Column(
            [
                ft.Row([ft.Text("Жимовая программа Гусеница (19 тренировок)", size=16, weight=ft.FontWeight.BOLD)], alignment=ft.MainAxisAlignment.CENTER),
                ft.Row([target_weight_field, start_date_text, ft.IconButton(icon=ft.Icons.CALENDAR_MONTH, on_click=open_date_picker)], alignment=ft.MainAxisAlignment.CENTER, wrap=True),
                days_selection_container,
                ft.Row(
                    [
                        ft.Button(content="Построить таблицу", on_click=build_plan),
                        ft.Button(content="Записать в Дневник", icon=ft.Icons.BOOK, on_click=write_to_diary, bgcolor=ft.Colors.BLUE_100),
                        ft.Button(content="Экспорт в Excel", icon=ft.Icons.FILE_DOWNLOAD, on_click=export_to_excel, bgcolor=ft.Colors.GREEN_100),
                    ],
                    alignment=ft.MainAxisAlignment.CENTER, wrap=True
                ),
                ft.Row([plan_error_text], alignment=ft.MainAxisAlignment.CENTER),
                plan_area,
            ],
            horizontal_alignment=ft.CrossAxisAlignment.CENTER,
            scroll=ft.ScrollMode.AUTO,
        )
    )

    tab3_content = ft.Container(
        expand=True,
        padding=20,
        content=ft.Column([
            ft.Text("Тренировочный дневник", size=20, weight=ft.FontWeight.BOLD),
            ft.Text("Отмечайте выполненные тренировки:", size=14, color=ft.Colors.GREY_700),
            ft.Divider(),
            diary_container
        ], scroll=ft.ScrollMode.AUTO)
    )

    tabs = ft.Tabs(
        selected_index=0,
        animation_duration=300,
        length=3,
        expand=True,
        content=ft.Column(
            expand=True,
            controls=[
                ft.TabBar(
                    tabs=[
                        ft.Tab(label="Приветствие АУФ"),
                        ft.Tab(label="Тренировочный план (жим)"),
                        ft.Tab(label="Дневник"),
                    ]
                ),
                ft.TabBarView(
                    expand=True,
                    controls=[tab1_content, tab2_content, tab3_content],
                ),
            ],
        ),
    )

    page.add(splash_view)

if __name__ == "__main__":
    ft.run(main, assets_dir="assets")